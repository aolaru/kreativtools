Synthetic ZIP fixture.
